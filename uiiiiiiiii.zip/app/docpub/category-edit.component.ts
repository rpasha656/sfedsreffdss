import { Component } from '@angular/core';
import { FileMetadataService, FileMetadataListing, SubCategories } from './index';
@Component({
    selector: 'as-edit-category',
    template: require('./category-edit.component.html')
})
export class CategoryEdit {

    public tableData = [];
    public Category = '';
    public SubCategory = '';
    public oldText = '';
    public oldSubcategory = '';
    public subcategory: SubCategories[];
    public subJsonData: Object[];
    public category: FileMetadataListing[];
    constructor(private filemetadataService: FileMetadataService) {
        this.subcategory = [];
        this.category = [new FileMetadataListing(this.subcategory)];
        this.filemetadataService.getCategories().subscribe(res => this.tableData = res);
    }
    changeSubCate(selectedCategory) {
        for (let x = 0; x < this.category.length; x++) {
            if (this.category[x].id === Number(selectedCategory.target.name)) {
                this.subJsonData = this.category[x].subCategories;
            }
        }
    }
    addCategory() {
        for (let i = 0; i < this.tableData.length; i++) {
            this.tableData[i].showSubcategory = true;
        }
        let obj = {
            'editable': true,
            'name': this.Category,
            'subCategory': [],
            'showSubcategory': false
        };
        this.tableData.push(obj);
        this.Category = '';
    }
    addSubCategory(row, id) {
        for (let i = 0; i < this.tableData.length; i++) {
            if (this.tableData[i].showSubcategory === false) {
                let eleId: string = 'addSubcategory';
                let inputValue = (<HTMLInputElement>document.getElementById(eleId)).value;
                console.log(id);
                let obj = {
                    'editable': true,
                    'name': inputValue
                };
                this.tableData[i].subCategory.push(obj);
                (<HTMLInputElement>document.getElementById(eleId)).name = '';
                this.tableData[i].showSubcategory = false;
                break;
            }
        }

    }
    deleteCategory(row) {
        console.log(row);
        let index = (this.tableData.indexOf(row));
        this.tableData.splice(index, 1);
    }
    deleteSubCategory(row: any, indexCat: any) {
        console.log(row);
        let index = (this.tableData[indexCat].subCategory.indexOf(row));
        if (index > -1) {
            this.tableData[indexCat].subCategory.splice(index, 1);
        }
    }

    enableSubCategory(row) {
        for (let i = 0; i < this.tableData.length; i++) {
            this.tableData[i].showSubcategory = true;
        }
        console.log(row);
        row.showSubcategory = false;
    }

    beginEdit(el: HTMLElement, index: string): void {
        console.log(el);
        this.oldText = this.tableData[index].name;
        this.tableData[index].editable = true;
    }
    beginsubCategoryEdit(el: HTMLElement, indexCat: string): void {
        let index = (this.tableData[indexCat].subCategory.indexOf(el));
        if (index > -1) {
            this.oldSubcategory = this.tableData[indexCat].subCategory[index].name;
            this.tableData[indexCat].subCategory[index].editable = true;
            console.log(this.tableData[indexCat].subCategory[index].editable);
        }
    }
    editDone(newText, index: string): void {
        console.log('edit done');
        newText.editable = false;
    }
    editsubCategoryDone(newText, indexCat: string): void {
        let index = (this.tableData[indexCat].subCategory.indexOf(newText));
        if (index > -1) {
            this.tableData[indexCat].subCategory[index].editable = false;
            this.tableData[indexCat].showSubcategory = false;
            console.log(this.tableData[indexCat].subCategory[index].editable);
        }
    }
    editCancel(newText, index: string): void {
        console.log('edit cancel');
        newText.name = this.oldText;
        newText.editable = false;
        this.oldText = '';
    }
    editsubCategoryCancel(newText, indexCat: string): void {
        let index = (this.tableData[indexCat].subCategory.indexOf(newText));
        if (index > -1) {
            this.tableData[indexCat].subCategory[index].editable = false;
            this.tableData[indexCat].showSubcategory = false;
            this.tableData[indexCat].subCategory[index].name = this.oldSubcategory;
        }
    }

    onRowClick(event, id) {
        console.log(event.target.outerText, id);
    }
}
