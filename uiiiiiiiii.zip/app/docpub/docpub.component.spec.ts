import {
    TestBed, inject
} from '@angular/core/testing';
import { Component } from '@angular/core';
import { DocpubModule } from './index';
import { UploadComponent } from './upload.component';
import { FileMetadataService } from './filemetadata.service';
@Component({
    selector: 'as-test',
    template: '<as-docpub></as-docpub>'
})
class TestComponent {
}
// Used for functionalities
let docpubCompiled;
let docpubCmp: UploadComponent;

describe('UploadComponent', () => {
    beforeEach(() => {
        jasmine.DEFAULT_TIMEOUT_INTERVAL = 300000;
        TestBed.configureTestingModule({
            declarations: [TestComponent],
            imports: [DocpubModule],
            providers: [FileMetadataService, UploadComponent
            ]
        });
    });
    it('Testing getCategories',
        inject([FileMetadataService], (filemetadataservice) => {

            expect(filemetadataservice).toBeDefined();

            expect(filemetadataservice.getCategories());
        }));
    it('Testing  getFileMetadatalisting',
        inject([FileMetadataService], (filemetadataservice) => {

            expect(filemetadataservice).toBeDefined();

            expect(filemetadataservice.getFileMetadatalisting('HUM'));
        }));
    it('Testing  addFileMetaData',
        inject([FileMetadataService], (filemetadataservice) => {

            expect(filemetadataservice).toBeDefined();

            expect(filemetadataservice.addFileMetaData());
        }));
    it('Testing Display Length',
        inject([UploadComponent], (uploadcomponent) => {
            let fixture = TestBed.createComponent(UploadComponent);
            fixture.componentInstance.fileMetadata.displayName = 'Name Changed';
            docpubCompiled = fixture.nativeElement;
            docpubCmp = fixture.debugElement.children[0].componentInstance;
            expect(uploadcomponent).toBeDefined();
            let displayName = docpubCompiled.querySelectorAll('#displayName')[0].getAttribute('ng-reflect-model');
            expect(displayName).toBeDefined(40);
        }));
    it('Testing Expiration Date',
        inject([UploadComponent], (uploadcomponent) => {
            let fixture = TestBed.createComponent(UploadComponent);
            fixture.componentInstance.fileMetadata.expirationDate = 'Date Changed';
            docpubCompiled = fixture.nativeElement;
            docpubCmp = fixture.debugElement.children[0].componentInstance;
            expect(uploadcomponent).toBeDefined();
            let expirationDate = docpubCompiled.querySelectorAll('#expDate')[0].getAttribute('ng-reflect-model');
            expect(expirationDate).toBeDefined('fileMetadata.expirationDate');
        }));
    it('Testing Preview',
        inject([UploadComponent], (uploadcomponent) => {
            let fixture = TestBed.createComponent(UploadComponent);
            fixture.componentInstance.fileMetadata.file = 'File Changed';
            docpubCompiled = fixture.nativeElement;
            docpubCmp = fixture.debugElement.children[0].componentInstance;
            expect(uploadcomponent).toBeDefined();
            let file = docpubCompiled.querySelectorAll('#file')[0].getAttribute('ng-reflect-model');
            expect(file).toBeDefined('fileMetadata.file');
        }));
    it('Increment',
        inject([UploadComponent], (uploadcomponent) => {
            let fixture = TestBed.createComponent(UploadComponent);
            fixture.componentInstance.fileMetadata.expirationDate = 'Date Changed';
            docpubCompiled = fixture.nativeElement;
            docpubCmp = fixture.debugElement.children[0].componentInstance;
            expect(uploadcomponent).toBeDefined();
            let expDate = docpubCompiled.querySelectorAll('#expDate')[0].getAttribute('ng-reflect-model');
            expect(expDate).toBeDefined('increment()');
        }));
    it('Decrement',
        inject([UploadComponent], (uploadcomponent) => {
            let fixture = TestBed.createComponent(UploadComponent);
            fixture.componentInstance.fileMetadata.expirationDate = 'Date Changed';
            docpubCompiled = fixture.nativeElement;
            docpubCmp = fixture.debugElement.children[0].componentInstance;
            expect(uploadcomponent).toBeDefined();
            let expDate = docpubCompiled.querySelectorAll('#expDate')[0].getAttribute('ng-reflect-model');
            expect(expDate).toBeDefined('decrement()');
        }));
});
